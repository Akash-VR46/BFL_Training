package com.example.activitieskotlin;

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log

public class MyStateChangeActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) : Unit {
        super.onCreate(savedInstanceState)
        Log.d("MyStateChangeActivity","onCreate")

    }

    override fun onRestoreInstanceState(
        savedInstanceState: Bundle
    ) : Unit{
        super.onRestoreInstanceState(savedInstanceState)
        Log.d("MyStateChangeActivity","onRestoreInstanceState")
    }

    override fun onRestart() :Unit{
        super.onRestart()
        Log.d("MyStateChangeActivity","onRestart")
    }
    override fun onStart() :Unit{
        super.onStart()
        Log.d("MyStateChangeActivity","onStart")
    }
    override fun onResume(): Unit{
        super.onResume()
        Log.d("MyStateChangeActivity","OnResume")

    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle): Unit {
        super.onSaveInstanceState(outState, outPersistentState)
        Log.d("MyStateChangeActivity","onSaveInstanceState")

    }
    override fun onPause():Unit{
        super.onPause()
        Log.d("MyStateChangeActivity","onPause")
    }
    override fun onStop():Unit{
        super.onStop()
        Log.d("MyStateChangeActivity","onStop")
    }
    override fun onDestroy():Unit{
        super.onDestroy()
        Log.d("MyStateChangeActivity","onDestroy")
    }

}